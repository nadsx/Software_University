﻿namespace Farm
{
    public class StartUp
    {
        public static void Main()
        {
            Cat cat = new Cat();

            cat.Eat();
            cat.Meow();
        }
    }
}
